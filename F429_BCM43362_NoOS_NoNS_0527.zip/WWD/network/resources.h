/* Automatically generated file - this comment ensures resources.h file creation */ 
